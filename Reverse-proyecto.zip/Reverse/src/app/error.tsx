"use client";

import { useEffect } from "react";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center px-4">
      <h1 className="text-xl font-semibold text-gray-800">Algo salió mal</h1>
      <p className="mt-2 text-gray-600 text-center max-w-md">
        No se pudo cargar la página. Revisa la consola del navegador (F12) para más detalles.
      </p>
      <button
        type="button"
        onClick={reset}
        className="mt-6 px-4 py-2 rounded-xl bg-reverse-lime text-reverse-black font-semibold hover:opacity-90"
      >
        Reintentar
      </button>
    </div>
  );
}
