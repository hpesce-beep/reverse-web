"use client";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="es">
      <body>
        <div style={{
          minHeight: "100vh",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: "1.5rem",
          fontFamily: "system-ui, sans-serif",
          color: "#0A0A0A",
        }}>
          <h1 style={{ fontSize: "1.25rem", fontWeight: 600 }}>Algo salió mal</h1>
          <p style={{ marginTop: "0.5rem", color: "#6B7280", textAlign: "center", maxWidth: "28rem" }}>
            No se pudo cargar la aplicación. Revisa la consola para más detalles.
          </p>
          <button
            type="button"
            onClick={() => reset()}
            style={{
              marginTop: "1.5rem",
              padding: "0.5rem 1rem",
              borderRadius: "0.75rem",
              background: "#73C544",
              color: "#0A0A0A",
              fontWeight: 600,
              border: "none",
              cursor: "pointer",
            }}
          >
            Reintentar
          </button>
        </div>
      </body>
    </html>
  );
}
