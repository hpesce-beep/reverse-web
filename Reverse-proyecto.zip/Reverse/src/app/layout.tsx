import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const metadata: Metadata = {
  title: "Reverse | Optimiza tu inventario. Maximiza tu liquidez.",
  description:
    "Valorización, liquidación y venta de inventario industrial y activos. Consultoría, tecnología y ejecución comercial con trazabilidad y economía circular.",
  keywords: [
    "inventario industrial",
    "liquidación activos",
    "marketplace B2B",
    "subastas industriales",
    "trazabilidad",
    "economía circular",
  ],
  openGraph: {
    title: "Reverse | Optimiza tu inventario. Maximiza tu liquidez.",
    description:
      "Valorización, liquidación y venta de inventario industrial. Tecnología, trazabilidad y ejecución end-to-end.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Reverse | Optimiza tu inventario. Maximiza tu liquidez.",
  },
  robots: "index, follow",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#4495F0",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="min-h-screen flex flex-col font-sans antialiased">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
