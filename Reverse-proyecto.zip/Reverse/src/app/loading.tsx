export default function Loading() {
  return (
    <div className="min-h-[40vh] flex items-center justify-center">
      <div className="w-10 h-10 rounded-full border-2 border-reverse-lime border-t-transparent animate-spin" />
    </div>
  );
}
