"use client";

import { useEffect } from "react";
import Link from "next/link";

export default function LoginPage() {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center px-4">
      <h1 className="text-2xl font-bold text-reverse-black">Sin inicio de sesión</h1>
      <p className="mt-2 text-reverse-muted text-center max-w-md">
        Este sitio no requiere login. Puedes agendar una reunión o explorar marketplaces y subastas directamente.
      </p>
      <div className="mt-6 flex flex-wrap gap-4 justify-center">
        <Link
          href="/"
          className="inline-flex items-center justify-center rounded-reverse bg-reverse-lime px-5 py-2.5 text-sm font-semibold text-reverse-black hover:opacity-90 transition-opacity"
        >
          Ir al inicio
        </Link>
        <Link
          href="/contacto"
          className="inline-flex items-center justify-center rounded-reverse border-2 border-reverse-blue text-reverse-blue px-5 py-2.5 text-sm font-semibold hover:bg-reverse-blue hover:text-gray-200 transition-colors"
        >
          Contacto
        </Link>
      </div>
    </div>
  );
}
