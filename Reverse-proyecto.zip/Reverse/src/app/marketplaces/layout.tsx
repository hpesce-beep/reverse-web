import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Marketplaces y subastas | Reverse",
  description: "Explora marketplaces activos y subastas próximas. Filtra por tipo, estado, industria y país. Procesos trazables y resultados medibles.",
};

export default function MarketplacesLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
