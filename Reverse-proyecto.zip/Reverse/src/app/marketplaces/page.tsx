"use client";

import { useMemo, useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { marketplacesData, type MarketplaceItem, type ItemType, type ItemStatus } from "@/data/marketplaces";
import { ExternalLink, MapPin, Calendar, Search } from "lucide-react";

function getTipoFromSearchParams(searchParams: URLSearchParams): ItemType | "all" {
  const t = searchParams.get("tipo");
  if (t === "marketplace" || t === "auction") return t;
  return "all";
}

export default function MarketplacesPage() {
  const searchParams = useSearchParams();
  const [typeFilter, setTypeFilter] = useState<ItemType | "all">(() =>
    getTipoFromSearchParams(searchParams)
  );

  useEffect(() => {
    setTypeFilter(getTipoFromSearchParams(searchParams));
  }, [searchParams]);
  const [statusFilter, setStatusFilter] = useState<ItemStatus | "all">("all");
  const [industryFilter, setIndustryFilter] = useState<string>("all");
  const [countryFilter, setCountryFilter] = useState<string>("all");
  const [search, setSearch] = useState("");

  const industries = useMemo(() => {
    const set = new Set(marketplacesData.map((m) => m.industry).filter(Boolean));
    return Array.from(set).sort();
  }, []);

  const countries = useMemo(() => {
    const set = new Set(marketplacesData.map((m) => m.country).filter(Boolean));
    return Array.from(set).sort();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return marketplacesData.filter((item) => {
      if (typeFilter !== "all" && item.type !== typeFilter) return false;
      if (statusFilter !== "all" && item.status !== statusFilter) return false;
      if (industryFilter !== "all" && item.industry !== industryFilter) return false;
      if (countryFilter !== "all" && item.country !== countryFilter) return false;
      if (q && !(item.title.toLowerCase().includes(q) || item.description.toLowerCase().includes(q) || (item.industry?.toLowerCase().includes(q)))) return false;
      return true;
    });
  }, [typeFilter, statusFilter, industryFilter, countryFilter, search]);

  return (
    <div className="py-12 lg:py-20 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-10">
          <h1 className="text-heading font-bold text-reverse-black">
            Marketplaces & Subastas
          </h1>
          <p className="mt-3 text-reverse-secondary max-w-2xl text-[1.0625rem]">
            Explora marketplaces activos y subastas próximas. Filtra por tipo, estado, industria o país.
          </p>
        </div>

        {/* Search */}
        <div className="relative max-w-md mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-reverse-muted" />
          <input
            type="search"
            placeholder="Buscar por título, descripción o industria..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-reverse border border-reverse-border bg-white text-reverse-black placeholder-reverse-muted focus:outline-none focus:ring-2 focus:ring-reverse-blue/20 focus:border-reverse-blue"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 items-end">
          <div>
            <label htmlFor="filter-type" className="block text-xs font-medium text-reverse-muted uppercase tracking-wider mb-1.5">
              Tipo
            </label>
            <select
              id="filter-type"
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as ItemType | "all")}
              className="rounded-reverse border border-reverse-border px-3 py-2.5 text-sm text-reverse-black bg-white focus:ring-2 focus:ring-reverse-blue/20 focus:border-reverse-blue"
            >
              <option value="all">Todos</option>
              <option value="marketplace">Marketplace</option>
              <option value="auction">Subasta</option>
            </select>
          </div>
          <div>
            <label htmlFor="filter-status" className="block text-xs font-medium text-reverse-muted uppercase tracking-wider mb-1.5">
              Estado
            </label>
            <select
              id="filter-status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as ItemStatus | "all")}
              className="rounded-reverse border border-reverse-border px-3 py-2.5 text-sm text-reverse-black bg-white focus:ring-2 focus:ring-reverse-blue/20 focus:border-reverse-blue"
            >
              <option value="all">Todos</option>
              <option value="active">Activo</option>
              <option value="upcoming">Próximo</option>
            </select>
          </div>
          <div>
            <label htmlFor="filter-industry" className="block text-xs font-medium text-reverse-muted uppercase tracking-wider mb-1.5">
              Industria
            </label>
            <select
              id="filter-industry"
              value={industryFilter}
              onChange={(e) => setIndustryFilter(e.target.value)}
              className="rounded-reverse border border-reverse-border px-3 py-2.5 text-sm text-reverse-black bg-white focus:ring-2 focus:ring-reverse-blue/20 focus:border-reverse-blue"
            >
              <option value="all">Todas</option>
              {industries.map((ind) => (
                <option key={ind} value={ind}>{ind}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="filter-country" className="block text-xs font-medium text-reverse-muted uppercase tracking-wider mb-1.5">
              País
            </label>
            <select
              id="filter-country"
              value={countryFilter}
              onChange={(e) => setCountryFilter(e.target.value)}
              className="rounded-reverse border border-reverse-border px-3 py-2.5 text-sm text-reverse-black bg-white focus:ring-2 focus:ring-reverse-blue/20 focus:border-reverse-blue"
            >
              <option value="all">Todos</option>
              {countries.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((item) => (
            <MarketplaceCard key={item.id} item={item} />
          ))}
        </div>

        {filtered.length === 0 && (
          <p className="mt-12 text-center text-reverse-muted text-[1rem]">
            No hay resultados con los filtros seleccionados. Prueba con otras opciones.
          </p>
        )}
      </div>
    </div>
  );
}

function MarketplaceCard({ item }: { item: MarketplaceItem }) {
  return (
    <article className="rounded-reverse-lg border border-reverse-border bg-white overflow-hidden hover:border-reverse-blue/25 hover:shadow-reverse-md transition-all">
      <div className="aspect-[16/10] bg-gradient-to-br from-reverse-soft-bg to-white flex items-center justify-center border-b border-reverse-border">
        <span className="text-5xl font-bold text-reverse-black/10">
          {item.type === "marketplace" ? "M" : "S"}
        </span>
      </div>
      <div className="p-5">
        <div className="flex flex-wrap gap-2">
          <span className="text-[11px] font-semibold px-2.5 py-1 rounded-md bg-reverse-blue text-white uppercase tracking-wide">
            {item.type === "marketplace" ? "Marketplace" : "Subasta"}
          </span>
          <span className={`text-[11px] font-semibold px-2.5 py-1 rounded-md uppercase tracking-wide ${
            item.status === "active" ? "bg-reverse-lime/20 text-reverse-black" : "bg-reverse-muted/20 text-reverse-secondary"
          }`}>
            {item.status === "active" ? "Activo" : "Próximo"}
          </span>
          {item.industry && (
            <span className="text-[11px] px-2.5 py-1 rounded-md bg-reverse-soft-bg text-reverse-muted">
              {item.industry}
            </span>
          )}
        </div>
        <h2 className="mt-3 font-semibold text-reverse-black text-[1.0625rem]">
          {item.title}
        </h2>
        <p className="mt-1.5 text-sm text-reverse-muted line-clamp-2">
          {item.description}
        </p>
        {(item.industry || item.country || item.endDate) && (
          <div className="mt-3 flex flex-wrap gap-3 text-xs text-reverse-muted">
            {(item.industry || item.country) && (
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" />
                {[item.industry, item.country].filter(Boolean).join(" · ")}
              </span>
            )}
            {item.endDate && (
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                Cierre: {item.endDate}
              </span>
            )}
          </div>
        )}
        {item.tags.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {item.tags.slice(0, 3).map((tag) => (
              <span key={tag} className="text-xs px-2 py-0.5 rounded bg-reverse-soft-bg text-reverse-muted">
                {tag}
              </span>
            ))}
          </div>
        )}
        <a
          href={item.url}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-reverse-blue hover:text-reverse-lime transition-colors"
        >
          Ir
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>
    </article>
  );
}
