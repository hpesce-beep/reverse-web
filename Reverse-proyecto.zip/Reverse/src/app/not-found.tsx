import Link from "next/link";

export default function NotFound() {
  return (
    <div
      className="min-h-[60vh] flex flex-col items-center justify-center px-4"
      style={{ minHeight: "60vh" }}
    >
      <h1 className="text-2xl font-bold text-reverse-black" style={{ color: "#0A0A0A", fontSize: "1.5rem" }}>
        Página no encontrada
      </h1>
      <p className="mt-2 text-reverse-muted text-center max-w-md" style={{ color: "#6B7280", marginTop: "0.5rem" }}>
        La ruta que buscas no existe o fue movida.
      </p>
      <Link
        href="/"
        className="mt-6 px-5 py-2.5 rounded-reverse bg-reverse-lime text-reverse-black font-semibold hover:opacity-90 transition-opacity"
        style={{
          marginTop: "1.5rem",
          padding: "0.625rem 1.25rem",
          borderRadius: "1rem",
          backgroundColor: "#73C544",
          color: "#0A0A0A",
          fontWeight: 600,
          textDecoration: "none",
        }}
      >
        Volver al inicio
      </Link>
    </div>
  );
}
