"use client";

import { Hero } from "@/components/home/Hero";
import { PainSection } from "@/components/home/PainSection";
import { ValueProposition } from "@/components/home/ValueProposition";
import { SolucionIntegralSection } from "@/components/home/SolucionIntegralSection";
import { PillarsSection } from "@/components/home/PillarsSection";
import { ProcessSection } from "@/components/home/ProcessSection";
import { MarketplacesPreview } from "@/components/home/MarketplacesPreview";
import { SocialProof } from "@/components/home/SocialProof";
import { FaqSection } from "@/components/home/FaqSection";
import { FinalCta } from "@/components/home/FinalCta";

export default function HomePage() {
  return (
    <>
      <Hero />
      <PainSection />
      <ValueProposition />
      <SolucionIntegralSection />
      <PillarsSection />
      <ProcessSection />
      <MarketplacesPreview />
      <SocialProof />
      <FaqSection />
      <FinalCta />
    </>
  );
}
