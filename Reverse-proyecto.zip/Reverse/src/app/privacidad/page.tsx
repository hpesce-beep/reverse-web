export const metadata = {
  title: "Privacidad | Reverse",
  description: "Política de privacidad de Reverse.",
};

export default function PrivacidadPage() {
  return (
    <div className="py-16 lg:py-24 bg-white min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-heading font-bold text-reverse-black">
          Política de privacidad
        </h1>
        <p className="mt-4 text-reverse-muted text-[1rem]">
          Este es un placeholder. Aquí irá la política de privacidad de Reverse (datos personales, cookies, contacto).
        </p>
      </div>
    </div>
  );
}
