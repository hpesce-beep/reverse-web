export const metadata = {
  title: "Términos | Reverse",
  description: "Términos y condiciones de uso de Reverse.",
};

export default function TerminosPage() {
  return (
    <div className="py-16 lg:py-24 bg-white min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-heading font-bold text-reverse-black">
          Términos y condiciones
        </h1>
        <p className="mt-4 text-reverse-muted text-[1rem]">
          Este es un placeholder. Aquí irán los términos y condiciones de uso de los servicios de Reverse.
        </p>
      </div>
    </div>
  );
}
