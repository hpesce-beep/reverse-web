import Link from "next/link";
import Image from "next/image";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/nosotros", label: "Quiénes somos" },
  { href: "/que-hacemos", label: "Qué hacemos" },
  { href: "/contacto", label: "Contacto" },
];

const LEGAL = [
  { href: "/privacidad", label: "Privacidad" },
  { href: "/terminos", label: "Términos" },
];

const CALENDLY_URL = "https://calendly.com";

export function Footer() {
  return (
    <footer className="bg-reverse-blue text-white" style={{ backgroundColor: "#4495F0" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          <div className="lg:col-span-1">
            <Link href="/" className="inline-block [&_img]:brightness-0 [&_img]:invert">
              <Image
                src="/logos/reverse.png"
                alt="Reverse"
                width={120}
                height={40}
                className="h-8 w-auto"
              />
            </Link>
            <p className="mt-4 text-sm text-white/70 max-w-xs">
              Valorización, liquidación y venta de inventario industrial con tecnología y trazabilidad.
            </p>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white/60">Navegación</h3>
            <ul className="mt-4 space-y-3">
              {NAV_LINKS.map(({ href, label }) => (
                <li key={href}>
                  <Link href={href} className="text-sm text-white/85 hover:text-reverse-lime transition-colors">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white/60">Legal</h3>
            <ul className="mt-4 space-y-3">
              {LEGAL.map(({ href, label }) => (
                <li key={href}>
                  <Link href={href} className="text-sm text-white/85 hover:text-reverse-lime transition-colors">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white/60">Contacto</h3>
            <ul className="mt-4 space-y-2 text-sm text-white/85">
              <li>
                <a href="mailto:contacto@reverse.cl" className="hover:text-reverse-lime transition-colors">
                  contacto@reverse.cl
                </a>
              </li>
              <li>
                <a href="tel:+56225550109" className="hover:text-reverse-lime transition-colors">
                  (2) 2555-0109
                </a>
              </li>
              <li>Santiago, Chile</li>
            </ul>
            <div className="mt-4 space-y-2">
              <a
                href={CALENDLY_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex justify-center w-full rounded-reverse bg-reverse-lime px-4 py-2.5 text-sm font-semibold text-reverse-black hover:opacity-90 transition-opacity"
              >
                Agendar reunión
              </a>
              <Link
                href="/marketplaces?tipo=marketplace"
                className="inline-flex justify-center w-full rounded-reverse border border-white/40 text-white px-4 py-2.5 text-sm font-semibold hover:bg-white/10 transition-colors"
              >
                Marketplaces
              </Link>
              <Link
                href="/marketplaces?tipo=auction"
                className="inline-flex justify-center w-full rounded-reverse border border-white/40 text-white px-4 py-2.5 text-sm font-semibold hover:bg-white/10 transition-colors"
              >
                Subastas
              </Link>
            </div>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-white/15 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-white/60">
            © {new Date().getFullYear()} Reverse. Todos los derechos reservados.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-white/60 hover:text-reverse-lime text-sm transition-colors" aria-label="LinkedIn">
              LinkedIn
            </a>
            <a href="#" className="text-white/60 hover:text-reverse-lime text-sm transition-colors" aria-label="Instagram">
              Instagram
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
