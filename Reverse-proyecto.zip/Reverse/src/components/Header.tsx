"use client";

import { useState, useEffect } from "react";
import { HeaderContent } from "@/components/HeaderContent";

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const headerBg = scrolled
    ? "bg-white/95 backdrop-blur-md border-b border-reverse-border shadow-reverse"
    : "bg-white";

  return <HeaderContent headerBg={headerBg} menuOpen={menuOpen} setMenuOpen={setMenuOpen} />;
}
