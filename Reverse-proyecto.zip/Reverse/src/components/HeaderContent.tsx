import React from "react";
import Link from "next/link";
import Image from "next/image";
import { Menu, X } from "lucide-react";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/nosotros", label: "Quiénes somos" },
  { href: "/que-hacemos", label: "Qué hacemos" },
  { href: "/contacto", label: "Contacto" },
];

const CALENDLY_URL = "https://calendly.com";

type HeaderContentProps = {
  headerBg: string;
  menuOpen: boolean;
  setMenuOpen: (v: boolean) => void;
};

export function HeaderContent({ headerBg, menuOpen, setMenuOpen }: HeaderContentProps) {
  return React.createElement(
    "header",
    { className: "sticky top-0 z-50 transition-all duration-200 " + headerBg },
    React.createElement(
      "div",
      { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" },
      React.createElement(
        "div",
        { className: "flex items-center justify-between h-16 lg:h-20" },
        React.createElement(
          Link,
          { href: "/", className: "flex items-center shrink-0", "aria-label": "Reverse - Inicio" },
          React.createElement(Image, { src: "/logos/reverse.png", alt: "Reverse", width: 120, height: 40, className: "h-7 w-auto lg:h-8", priority: true })
        ),
        React.createElement(
          "nav",
          { className: "hidden lg:flex items-center gap-8", "aria-label": "Navegación principal" },
          ...NAV_LINKS.map(({ href, label }) =>
            React.createElement(Link, { key: href, href, className: "text-sm font-medium text-reverse-secondary hover:text-reverse-blue transition-colors" }, label)
          )
        ),
        React.createElement(
          "div",
          { className: "hidden lg:flex items-center gap-3" },
          React.createElement(Link, { href: "/marketplaces?tipo=marketplace", className: "inline-flex items-center justify-center rounded-reverse border-2 border-reverse-blue text-reverse-blue px-4 py-2 text-sm font-semibold hover:bg-reverse-blue hover:text-gray-200 transition-colors" }, "Marketplaces"),
          React.createElement(Link, { href: "/marketplaces?tipo=auction", className: "inline-flex items-center justify-center rounded-reverse border-2 border-reverse-blue text-reverse-blue px-4 py-2 text-sm font-semibold hover:bg-reverse-blue hover:text-gray-200 transition-colors" }, "Subastas"),
          React.createElement("a", { href: CALENDLY_URL, target: "_blank", rel: "noopener noreferrer", className: "inline-flex items-center justify-center rounded-reverse bg-reverse-lime px-5 py-2.5 text-sm font-semibold text-reverse-black hover:opacity-90 transition-opacity shadow-reverse" }, "Agendar reunión")
        ),
        React.createElement(
          "button",
          { type: "button", onClick: () => setMenuOpen(!menuOpen), className: "lg:hidden p-2 rounded-reverse text-reverse-black hover:bg-reverse-soft-bg", "aria-expanded": menuOpen, "aria-label": menuOpen ? "Cerrar menú" : "Abrir menú" },
          menuOpen ? React.createElement(X, { className: "w-6 h-6", strokeWidth: 2 }) : React.createElement(Menu, { className: "w-6 h-6", strokeWidth: 2 })
        )
      ),
      menuOpen &&
        React.createElement(
          "div",
          { className: "lg:hidden py-4 border-t border-reverse-border bg-white animate-fade-in" },
          React.createElement(
            "nav",
            { className: "flex flex-col gap-1", "aria-label": "Menú móvil" },
            ...NAV_LINKS.map(({ href, label }) =>
              React.createElement(Link, { key: href, href, onClick: () => setMenuOpen(false), className: "py-2.5 px-1 text-reverse-black font-medium hover:text-reverse-blue" }, label)
            ),
            React.createElement(
              "div",
              { className: "mt-4 flex flex-col gap-2" },
              React.createElement(Link, { href: "/marketplaces?tipo=marketplace", onClick: () => setMenuOpen(false), className: "inline-flex justify-center rounded-reverse border-2 border-reverse-blue text-reverse-blue px-4 py-3 text-sm font-semibold hover:bg-reverse-blue hover:text-gray-200 transition-colors" }, "Marketplaces"),
              React.createElement(Link, { href: "/marketplaces?tipo=auction", onClick: () => setMenuOpen(false), className: "inline-flex justify-center rounded-reverse border-2 border-reverse-blue text-reverse-blue px-4 py-3 text-sm font-semibold hover:bg-reverse-blue hover:text-gray-200 transition-colors" }, "Subastas"),
              React.createElement("a", { href: CALENDLY_URL, target: "_blank", rel: "noopener noreferrer", className: "inline-flex justify-center rounded-reverse bg-reverse-lime px-4 py-3 text-sm font-semibold text-reverse-black" }, "Agendar reunión")
            )
          )
        )
    )
  );
}
