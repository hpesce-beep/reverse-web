"use client";

import Image from "next/image";

/**
 * La ilustración de apoyo asoma por el borde y rellena con un pedazo visible (fondo blanco).
 */
export function ApoyoVisualSection() {
  return (
    <section className="relative py-16 lg:py-24 bg-white overflow-hidden" aria-hidden>
      <div className="absolute inset-y-0 right-0 w-full max-w-[55%] lg:max-w-[45%] min-h-[280px] lg:min-h-[320px] bg-white">
        <Image
          src="/images/apoyo-reverse.png"
          alt=""
          fill
          className="object-cover object-left rounded-l-2xl"
          sizes="50vw"
        />
      </div>
    </section>
  );
}
