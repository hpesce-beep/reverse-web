import Image from "next/image";
import { clientLogos } from "@/data/marketplaces";

export function ClientsSection() {
  return (
    <section className="py-20 lg:py-28 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl sm:text-3xl font-bold text-reverse-black text-center tracking-tight">
          Clientes que confían en nosotros
        </h2>
        <p className="mt-3 text-gray-600 text-center max-w-xl mx-auto">
          Empresas líderes que valorizan y liquidan inventario con Reverse.
        </p>
        <div className="mt-14 grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {clientLogos.map((client) => (
            <div
              key={client.name}
              className="flex items-center justify-center rounded-2xl bg-white border border-gray-100 shadow-sm hover:border-reverse-green/20 transition-all duration-300 p-6 sm:p-8 min-h-[120px] sm:min-h-[140px]"
            >
              <div className="relative w-full h-14 sm:h-16 flex items-center justify-center">
                <Image
                  src={client.src}
                  alt={`Logo ${client.name}`}
                  width={180}
                  height={72}
                  className="object-contain max-h-full w-auto"
                  sizes="(max-width: 1024px) 50vw, 180px"
                  unoptimized
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
