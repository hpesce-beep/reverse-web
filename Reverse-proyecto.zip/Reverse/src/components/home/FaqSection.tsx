"use client";

import { useState } from "react";
import { faqItems } from "@/data/marketplaces";
import { ChevronDown } from "lucide-react";

export function FaqSection() {
  const [openId, setOpenId] = useState<string | null>(null);

  return (
    <section className="py-14 lg:py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-display font-bold text-reverse-black text-center">
          Preguntas frecuentes
        </h2>
        <p className="mt-4 text-reverse-muted text-center text-lg lg:text-xl">
          Respuestas concisas para empresas.
        </p>

        <div className="mt-14 space-y-3">
          {faqItems.map((item) => {
            const id = item.q.slice(0, 25).replace(/\s/g, "-");
            const isOpen = openId === id;
            return (
              <div
                key={id}
                className="rounded-reverse border border-reverse-border overflow-hidden bg-reverse-soft-bg/50"
              >
                <button
                  type="button"
                  onClick={() => setOpenId(isOpen ? null : id)}
                  className="w-full flex items-center justify-between gap-4 px-6 py-5 text-left font-medium text-reverse-black hover:bg-white/60 transition-colors"
                  aria-expanded={isOpen}
                  aria-controls={`faq-${id}`}
                  id={`faq-btn-${id}`}
                >
                  <span className="text-base lg:text-lg">{item.q}</span>
                  <span
                    className={`shrink-0 w-8 h-8 flex items-center justify-center rounded-lg bg-white border border-reverse-border text-reverse-blue transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}
                    aria-hidden
                  >
                    <ChevronDown className="w-4 h-4" strokeWidth={2} />
                  </span>
                </button>
                <div
                  id={`faq-${id}`}
                  role="region"
                  aria-labelledby={`faq-btn-${id}`}
                  className="overflow-hidden transition-[max-height] duration-200 ease-out"
                  style={{ maxHeight: isOpen ? "500px" : "0" }}
                >
                  <div className="px-6 pb-5 pt-0 text-reverse-secondary text-base lg:text-lg leading-relaxed">
                    {item.a}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
