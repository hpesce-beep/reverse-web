import { featureBadges } from "@/data/marketplaces";

export function FeatureBadges() {
  return (
    <section className="py-16 lg:py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl sm:text-3xl font-bold text-reverse-black text-center tracking-tight">
          Apalancados en tecnología
        </h2>
        <p className="mt-4 text-gray-600 text-center max-w-2xl mx-auto">
          IA, trazabilidad y sostenibilidad en el centro del proceso.
        </p>
        <div className="mt-12 grid md:grid-cols-3 gap-8">
          {featureBadges.map((badge) => (
            <div
              key={badge.id}
              className="rounded-2xl bg-white border border-gray-100 p-6 text-center shadow-sm hover:border-[#73C544]/30 hover:shadow-md transition-all"
            >
              <div className="w-14 h-14 rounded-xl bg-[#73C544]/15 flex items-center justify-center mx-auto text-2xl font-bold text-[#73C544]">
                {badge.id === "ai" ? "IA" : badge.id === "trace" ? "≡" : "♻"}
              </div>
              <h3 className="mt-4 font-semibold text-reverse-black">{badge.title}</h3>
              <p className="mt-2 text-sm text-gray-600">{badge.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
