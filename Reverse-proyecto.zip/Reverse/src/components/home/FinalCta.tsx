"use client";

import Link from "next/link";

const CALENDLY_URL = "https://calendly.com";

export function FinalCta() {
  return (
    <section className="py-16 lg:py-24 bg-reverse-blue" style={{ backgroundColor: "#4495F0" }}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-display font-bold text-white animate-fade-in">
          ¿Listo para convertir inventario en liquidez?
        </h2>
        <p className="mt-6 text-white/90 text-lg lg:text-xl leading-relaxed">
          Agenda una reunión o explora nuestros marketplaces y subastas activas.
        </p>

        <div className="mt-12 flex flex-wrap justify-center gap-5">
          <a
            href={CALENDLY_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center rounded-reverse bg-reverse-lime px-6 py-3 text-sm font-semibold text-reverse-black hover:opacity-90 transition-opacity shadow-reverse"
          >
            Agendar reunión
          </a>
          <Link
            href="/marketplaces"
            className="inline-flex items-center justify-center rounded-reverse border-2 border-white text-white px-6 py-3 text-sm font-semibold hover:bg-white hover:text-reverse-black transition-colors"
          >
            Ver marketplaces y subastas
          </Link>
        </div>

        <p className="mt-10 text-base text-white/80">
          <a href="mailto:contacto@reverse.cl" className="underline hover:no-underline font-medium text-white/90">
            contacto@reverse.cl
          </a>
          {" · "}
          Respondemos en 24h
        </p>
      </div>
    </section>
  );
}
