"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";

const CALENDLY_URL = "https://calendly.com";

export function Hero() {
  const [overlayOpacity, setOverlayOpacity] = useState(1);

  useEffect(() => {
    const onScroll = () => {
      const y = typeof window !== "undefined" ? window.scrollY : 0;
      const fadeOver = 500;
      const minOpacity = 0.4;
      const next = Math.max(minOpacity, 1 - (y / fadeOver) * (1 - minOpacity));
      setOverlayOpacity(next);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <section className="relative min-h-[85vh] lg:min-h-[90vh] flex flex-col justify-center overflow-hidden pt-8 pb-20 lg:pt-12 lg:pb-28">
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/fondo-hero.png"
          alt=""
          fill
          className="object-cover object-center"
          priority
          sizes="100vw"
        />
        <div
          className="absolute inset-0 bg-gradient-to-r from-white/90 via-white/85 to-white/40 lg:to-transparent transition-opacity duration-200"
          style={{ opacity: overlayOpacity }}
          aria-hidden
        />
      </div>
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-3xl">
          <div className="animate-fade-in">
            <p className="text-sm font-semibold text-reverse-muted uppercase tracking-[0.2em]">
              VALORIZACIÓN · TECNOLOGÍA · TRAZABILIDAD
            </p>
            <h1 className="mt-5 text-display font-bold text-reverse-black tracking-tight leading-[1.1]">
              Optimiza tu inventario.
              <br />
              <span className="text-reverse-lime">Maximiza tu liquidez.</span>
            </h1>
            <p className="mt-8 text-xl text-reverse-secondary max-w-2xl leading-relaxed">
              Reverse nace desde la experiencia y red construida por el Ecosistema de Xinergy y Dux, porque creemos que el capital no debería quedar atrapado en inventario y activos subutilizados.
            </p>
            <p className="mt-5 text-xl text-reverse-secondary max-w-2xl leading-relaxed">
              Queremos que las empresas recuperen liquidez y foco operacional sin sacrificar continuidad, y que esos activos vuelvan a generar valor en lugar de quedar olvidados o deteriorarse.
            </p>
            <div className="mt-12 flex flex-wrap gap-4">
              <a
                href={CALENDLY_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center rounded-reverse bg-reverse-lime px-6 py-3 text-sm font-semibold text-reverse-black hover:opacity-90 transition-opacity shadow-reverse"
              >
                Agendar reunión
              </a>
              <Link
                href="/marketplaces"
                className="inline-flex items-center justify-center rounded-reverse border-2 border-reverse-blue text-reverse-blue px-6 py-3 text-sm font-semibold hover:bg-reverse-blue hover:text-gray-200 transition-colors"
              >
                Ver marketplaces y subastas
              </Link>
            </div>
            <p className="mt-8 text-base text-reverse-muted">
              Ecosistema Xinergy y Dux · Proceso trazable y end-to-end.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
