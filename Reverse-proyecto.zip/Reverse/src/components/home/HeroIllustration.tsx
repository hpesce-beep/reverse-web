"use client";

/**
 * Custom abstract illustration: 3D-ish grid of "asset tiles" with lime/blue glow.
 * No external images — pure CSS/SVG for inventory intelligence / marketplace network feel.
 */
export function HeroIllustration() {
  return (
    <div className="relative w-full aspect-[4/3] max-w-[520px] mx-auto lg:mx-0">
      {/* Gradient + noise overlay */}
      <div
        className="absolute inset-0 rounded-[1.25rem] overflow-hidden"
        style={{
          background: "linear-gradient(135deg, rgba(68, 149, 240, 0.04) 0%, rgba(115, 197, 68, 0.06) 50%, rgba(68, 149, 240, 0.03) 100%)",
          boxShadow: "inset 0 0 0 1px rgba(68, 149, 240, 0.1)",
        }}
      >
        {/* Subtle noise */}
        <div
          className="absolute inset-0 opacity-[0.4]"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
          }}
        />
      </div>

      {/* Grid of asset tiles */}
      <div className="absolute inset-4 lg:inset-6 flex flex-col gap-2 lg:gap-3">
        {/* Row 1 */}
        <div className="flex gap-2 lg:gap-3 flex-1 min-h-0">
          <Tile glow="lime" delay={0} />
          <Tile glow="blue" delay={0.05} />
          <Tile glow="lime" delay={0.1} small />
        </div>
        {/* Row 2 */}
        <div className="flex gap-2 lg:gap-3 flex-1 min-h-0">
          <Tile glow="blue" delay={0.08} small />
          <Tile glow="lime" delay={0.12} />
          <Tile glow="blue" delay={0.03} />
        </div>
        {/* Row 3 */}
        <div className="flex gap-2 lg:gap-3 flex-1 min-h-0">
          <Tile glow="lime" delay={0.06} />
          <Tile glow="lime" delay={0.15} small />
          <Tile glow="blue" delay={0.1} />
        </div>
      </div>

      {/* Center glow */}
      <div
        className="absolute inset-0 rounded-[1.25rem] pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 60% 50% at 50% 50%, rgba(115, 197, 68, 0.12) 0%, transparent 70%)",
        }}
      />
    </div>
  );
}

function Tile({
  glow,
  delay,
  small,
}: {
  glow: "lime" | "blue";
  delay: number;
  small?: boolean;
}) {
  const isLime = glow === "lime";
  return (
    <div
      className={`flex-1 rounded-xl flex items-center justify-center min-w-0 transition-transform duration-300 hover:scale-[1.02] ${
        small ? "min-h-[3rem]" : ""
      }`}
      style={{
        background: isLime
          ? "linear-gradient(145deg, rgba(115, 197, 68, 0.14) 0%, rgba(115, 197, 68, 0.04) 100%)"
          : "linear-gradient(145deg, rgba(68, 149, 240, 0.12) 0%, rgba(68, 149, 240, 0.03) 100%)",
        boxShadow: `inset 0 0 0 1px ${isLime ? "rgba(115, 197, 68, 0.25)" : "rgba(68, 149, 240, 0.2)"}`,
        animationDelay: `${delay}s`,
      }}
    >
      <div
        className={`rounded-lg ${small ? "w-4 h-4" : "w-6 h-6"}`}
        style={{
          background: isLime ? "rgba(115, 197, 68, 0.4)" : "rgba(68, 149, 240, 0.35)",
          boxShadow: isLime ? "0 0 12px rgba(115, 197, 68, 0.3)" : "0 0 10px rgba(68, 149, 240, 0.25)",
        }}
      />
    </div>
  );
}
