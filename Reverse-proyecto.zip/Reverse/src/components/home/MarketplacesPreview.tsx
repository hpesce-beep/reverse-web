"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { marketplacesData } from "@/data/marketplaces";
import type { ItemType, ItemStatus } from "@/data/marketplaces";
import { ExternalLink, MapPin, Calendar } from "lucide-react";

type FilterType = "all" | ItemType | ItemStatus;
const FILTERS: { id: FilterType; label: string }[] = [
  { id: "all", label: "Todos" },
  { id: "marketplace", label: "Marketplaces" },
  { id: "auction", label: "Subastas" },
  { id: "active", label: "Activos" },
  { id: "upcoming", label: "Próximos" },
];

const previewItems = marketplacesData.slice(0, 6);

export function MarketplacesPreview() {
  const [filter, setFilter] = useState<FilterType>("all");

  const filtered = useMemo(() => {
    if (filter === "all") return previewItems;
    if (filter === "marketplace" || filter === "auction") {
      return previewItems.filter((i) => i.type === filter);
    }
    return previewItems.filter((i) => i.status === filter);
  }, [filter]);

  return (
    <section className="py-14 lg:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-sm font-semibold text-reverse-muted uppercase tracking-[0.15em]">
          Casos de éxito
        </p>
        <h2 className="mt-3 text-display font-bold text-reverse-black">
          Explora marketplaces y subastas
        </h2>
        <p className="mt-5 text-reverse-secondary max-w-3xl text-lg lg:text-xl leading-relaxed">
          Procesos trazables y resultados medibles. Filtra por tipo o estado.
        </p>

        <div className="mt-10 flex flex-wrap gap-3">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id)}
              className={`px-5 py-2.5 rounded-full text-base font-medium transition-colors ${
                filter === f.id
                  ? "bg-reverse-blue text-white"
                  : "bg-reverse-soft-bg text-reverse-secondary hover:bg-reverse-border"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((item) => (
            <article
              key={item.id}
              className="group rounded-reverse-lg border border-reverse-border bg-white overflow-hidden hover:border-reverse-blue/30 hover:shadow-reverse-md transition-all animate-fade-in"
            >
              <div className="aspect-[16/10] bg-gradient-to-br from-reverse-soft-bg to-white flex items-center justify-center border-b border-reverse-border">
                <span className="text-5xl font-bold text-reverse-blue/10 group-hover:text-reverse-lime/30 transition-colors">
                  {item.type === "marketplace" ? "M" : "S"}
                </span>
              </div>
              <div className="p-6">
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs font-semibold px-3 py-1.5 rounded-md bg-reverse-blue text-white uppercase tracking-wide">
                    {item.type === "marketplace" ? "Marketplace" : "Subasta"}
                  </span>
                  <span className={`text-xs font-semibold px-3 py-1.5 rounded-md uppercase tracking-wide ${
                    item.status === "active" ? "bg-reverse-lime/20 text-reverse-blue" : "bg-reverse-muted/20 text-reverse-secondary"
                  }`}>
                    {item.status === "active" ? "Activo" : "Próximo"}
                  </span>
                </div>
                <h3 className="mt-4 font-semibold text-reverse-black text-lg">
                  {item.title}
                </h3>
                <p className="mt-2 text-base text-reverse-muted line-clamp-2 leading-relaxed">
                  {item.description}
                </p>
                {(item.industry || item.country) && (
                  <div className="mt-4 flex flex-wrap gap-3 text-sm text-reverse-muted">
                    {item.industry && (
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5" />
                        {item.industry}
                        {item.country && ` · ${item.country}`}
                      </span>
                    )}
                    {item.endDate && (
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {item.endDate}
                      </span>
                    )}
                  </div>
                )}
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-5 inline-flex items-center gap-1.5 text-base font-semibold text-reverse-blue hover:text-reverse-lime transition-colors"
                >
                  Ir
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link
            href="/marketplaces"
            className="inline-flex items-center justify-center rounded-reverse bg-reverse-lime px-6 py-3.5 text-base font-semibold text-reverse-black hover:opacity-90 transition-opacity shadow-reverse"
          >
            Ver todos los marketplaces y subastas
          </Link>
        </div>
      </div>
    </section>
  );
}
