"use client";

import { Package, TrendingDown, FileWarning, RotateCcw } from "lucide-react";

const BULLETS = [
  { icon: Package, text: "Caja atrapada en inventario que no rota o tiene baja trazabilidad económica." },
  { icon: TrendingDown, text: "Costos de almacenamiento (15–25% del valor del inventario por año) y pérdida de valor (40–70% del precio original)." },
  { icon: FileWarning, text: "Falta de trazabilidad y auditoría del proceso de liquidación." },
  { icon: RotateCcw, text: "Oportunidad de economía circular y recupero desaprovechada; liquidación tradicional 1–2% del valor libro." },
];

export function PainSection() {
  return (
    <section className="py-14 lg:py-20 bg-reverse-soft-bg">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-sm font-semibold text-reverse-muted uppercase tracking-[0.15em]">
          El problema
        </p>
        <h2 className="mt-3 text-display font-bold text-reverse-black">
          Inventario inmovilizado frena tu operación
        </h2>

        <ul className="mt-14 lg:mt-16 space-y-10 lg:space-y-12">
          {BULLETS.map((item, i) => (
            <li
              key={i}
              className="flex gap-5 lg:gap-6 items-start animate-fade-in"
              style={{ animationDelay: `${i * 0.05}s` }}
            >
              <span className="shrink-0 w-12 h-12 lg:w-14 lg:h-14 rounded-reverse bg-white border border-reverse-border flex items-center justify-center text-reverse-lime">
                <item.icon className="w-6 h-6 lg:w-7 lg:h-7" strokeWidth={2} />
              </span>
              <span className="text-reverse-secondary text-lg lg:text-xl leading-relaxed pt-1">
                {item.text}
              </span>
            </li>
          ))}
        </ul>

        <div className="mt-16 lg:mt-20 p-6 lg:p-8 rounded-reverse-lg border border-reverse-border bg-white shadow-reverse animate-fade-in">
          <p className="text-base font-semibold text-reverse-muted uppercase tracking-wider">
            Dato de referencia
          </p>
          <p className="mt-2 text-xl lg:text-2xl font-semibold text-reverse-black">
            Slow / no movers: <span className="text-reverse-lime">15–30%</span> típico del inventario.
          </p>
          <p className="mt-1 text-base lg:text-lg text-reverse-muted">
            ~10% del capital de trabajo anual suele quedar inmovilizado.
          </p>
        </div>
      </div>
    </section>
  );
}
