"use client";

import Link from "next/link";
import { BarChart3, Store, Gavel, Truck, Network } from "lucide-react";
import { pillars } from "@/data/marketplaces";
import { ChevronRight } from "lucide-react";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  chart: BarChart3,
  store: Store,
  gavel: Gavel,
  truck: Truck,
  network: Network,
};

export function PillarsSection() {
  return (
    <section className="py-14 lg:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-sm font-semibold text-reverse-muted uppercase tracking-[0.15em]">
          Qué hacemos
        </p>
        <h2 className="mt-3 text-display font-bold text-reverse-black">
          Cinco pilares
        </h2>
        <p className="mt-5 text-reverse-secondary max-w-3xl text-lg lg:text-xl leading-relaxed">
          Abordamos el desafío de punta a punta: desde el diagnóstico hasta la captura de valor.
        </p>

        <div className="mt-14 lg:mt-16 grid sm:grid-cols-2 lg:grid-cols-5 gap-6 lg:gap-8">
          {pillars.map((pillar) => {
            const Icon = iconMap[pillar.icon] ?? BarChart3;
            return (
              <div
                key={pillar.id}
                className="rounded-reverse-lg border border-reverse-border bg-reverse-soft-bg/50 p-6 lg:p-8 flex flex-col hover:border-reverse-blue/20 hover:shadow-reverse-md transition-all animate-fade-in"
              >
                <div className="w-12 h-12 rounded-reverse bg-reverse-blue flex items-center justify-center text-reverse-lime">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="mt-5 font-semibold text-reverse-black text-lg">
                  {pillar.title}
                </h3>
                <p className="mt-3 text-base text-reverse-muted leading-relaxed line-clamp-3">
                  {pillar.description}
                </p>
                <Link
                  href="/que-hacemos"
                  className="mt-5 inline-flex items-center gap-1 text-base font-medium text-reverse-blue hover:text-reverse-lime transition-colors group"
                >
                  Conocer más
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </Link>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
