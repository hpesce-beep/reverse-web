"use client";

import Image from "next/image";
import Link from "next/link";
import { processSteps } from "@/data/marketplaces";
import { Check, Calendar } from "lucide-react";

const FLOW_ICONS = ["/images/flow/icono-1.png", "/images/flow/icono-2.png", "/images/flow/icono-3.png", "/images/flow/icono-4.png", "/images/flow/icono-5.png"] as const;
const CALENDLY_URL = "https://calendly.com";

const CHECKLIST = [
  "Inventario o listado de activos a valorizar",
  "Información básica de condición y ubicación",
  "Objetivos claros (caja, disponibilidad, espacio)",
];

export function ProcessSection() {
  return (
    <section className="process-section-2026 relative py-16 lg:py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-white via-reverse-soft-bg/50 to-white pointer-events-none" aria-hidden />
      <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-reverse-lime/[0.03] rounded-full blur-3xl pointer-events-none" aria-hidden />
      <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-reverse-blue/[0.04] rounded-full blur-3xl pointer-events-none" aria-hidden />

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <header className="text-center max-w-3xl mx-auto mb-10 lg:mb-12">
          <p className="text-xs font-bold text-reverse-lime uppercase tracking-[0.25em] animate-process-step" style={{ animationDelay: "0s" }}>
            Cómo lo hacemos
          </p>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold text-reverse-black tracking-tight animate-process-step" style={{ animationDelay: "0.08s" }}>
            Proceso end-to-end
          </h2>
          <p className="mt-4 text-base lg:text-lg text-reverse-secondary leading-relaxed animate-process-step" style={{ animationDelay: "0.16s" }}>
            De inventario a caja, con tecnología y trazabilidad en cada paso.
          </p>
        </header>

        <div className="relative">
          <div
            className="absolute left-[21px] sm:left-6 top-6 bottom-6 w-0.5 rounded-full process-timeline-line hidden sm:block"
            aria-hidden
          />

          <ul className="space-y-4 lg:space-y-5">
            {processSteps.map((step, index) => (
              <li
                key={step.step}
                className="process-step-card animate-process-step relative flex gap-4 sm:gap-6 items-start sm:pl-4"
                style={{ animationDelay: `${0.25 + index * 0.1}s` }}
              >
                <div className="absolute left-0 top-4 w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-white border-2 border-reverse-lime shadow-[0_0_0_4px_rgba(115,197,68,0.15)] hidden sm:flex items-center justify-center z-10 process-step-dot">
                  <span className="text-sm sm:text-base font-bold text-reverse-lime tabular-nums">{step.step}</span>
                </div>

                <div className="flex-1 min-w-0 pl-0 sm:pl-6">
                  <div className="group process-card rounded-xl border border-reverse-border bg-white/90 backdrop-blur-sm p-3 sm:p-4 shadow-sm hover:shadow-lg hover:border-reverse-lime/40 hover:bg-white transition-all duration-300 ease-out">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                      <div className="flex items-center gap-3 sm:block sm:w-28 shrink-0">
                        <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-lg bg-reverse-lime/10 border border-reverse-lime/20 flex items-center justify-center overflow-hidden group-hover:bg-reverse-lime/15 group-hover:border-reverse-lime/30 transition-colors">
                          <Image
                            src={FLOW_ICONS[index]}
                            alt=""
                            width={48}
                            height={48}
                            className="w-full h-full object-contain p-1"
                          />
                        </div>
                        <h3 className="sm:mt-2 text-base sm:text-lg font-bold text-reverse-black">{step.title}</h3>
                      </div>
                      <p className="text-reverse-secondary text-sm lg:text-base leading-snug flex-1">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* Bloque CTA: qué necesitas + Agendar reunión */}
        <div
          className="process-card mt-10 lg:mt-12 rounded-2xl border-2 border-reverse-lime/30 bg-white shadow-md hover:shadow-xl hover:border-reverse-lime/50 transition-all duration-300 animate-process-step overflow-hidden"
          style={{ animationDelay: "0.85s" }}
        >
          <div className="p-6 sm:p-8 lg:p-8 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            <div className="flex-1">
              <h3 className="text-lg sm:text-xl font-bold text-reverse-black">
                ¿Listo para partir?
              </h3>
              <p className="text-reverse-secondary text-sm mt-1 mb-4">
                Solo necesitas esto para agendar tu primera reunión:
              </p>
              <ul className="space-y-2">
                {CHECKLIST.map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-reverse-secondary text-sm lg:text-base">
                    <span className="shrink-0 w-6 h-6 rounded-full bg-reverse-lime/20 flex items-center justify-center">
                      <Check className="w-3.5 h-3.5 text-reverse-lime" strokeWidth={2.5} />
                    </span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="shrink-0 lg:pl-8">
              <Link
                href={CALENDLY_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="cta-agendar inline-flex items-center justify-center gap-2 w-full sm:w-auto min-w-[240px] px-8 py-4 text-base font-bold text-reverse-black bg-reverse-lime rounded-xl shadow-lg hover:bg-reverse-lime/90 hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all duration-200"
              >
                <Calendar className="w-5 h-5 shrink-0" aria-hidden />
                Agendar reunión
              </Link>
              <p className="text-xs text-reverse-muted mt-3 text-center lg:text-left">
                Sin compromiso · Respuesta rápida
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
