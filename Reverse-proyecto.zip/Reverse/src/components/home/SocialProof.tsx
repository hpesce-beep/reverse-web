"use client";

import Image from "next/image";
import { clientLogos, testimonials } from "@/data/marketplaces";

export function SocialProof() {
  return (
    <section className="py-14 lg:py-20 bg-reverse-soft-bg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-display font-bold text-reverse-black text-center animate-fade-in">
          Clientes que confían en nosotros
        </h2>
        <p className="mt-4 text-reverse-muted text-center max-w-2xl mx-auto text-lg lg:text-xl">
          Empresas líderes que valorizan y liquidan inventario con Reverse.
        </p>

        <div className="mt-14 overflow-hidden animate-fade-in">
          <div className="flex animate-marquee gap-12 lg:gap-16 items-center py-6">
            {[...clientLogos, ...clientLogos].map((client, i) => {
              const darkBg = "darkBg" in client && client.darkBg;
              return (
                <div
                  key={`${client.name}-${i}`}
                  className={`shrink-0 flex items-center justify-center w-40 h-16 rounded-reverse border px-6 ${
                    darkBg
                      ? "bg-reverse-secondary border-reverse-secondary"
                      : "bg-white border-reverse-border"
                  }`}
                >
                  <Image
                    src={client.src}
                    alt={client.name}
                    width={140}
                    height={48}
                    className="object-contain max-h-10 w-auto"
                    sizes="140px"
                    unoptimized
                  />
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-20 grid sm:grid-cols-2 gap-8">
          {testimonials.map((t, i) => (
            <blockquote
              key={i}
              className="rounded-reverse-lg border border-reverse-border bg-white p-8 shadow-reverse animate-fade-in"
            >
              <p className="text-reverse-secondary text-lg leading-relaxed">
                &ldquo;{t.quote}&rdquo;
              </p>
              <footer className="mt-5 text-base text-reverse-muted">
                — {t.role}, {t.industry}
              </footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}
