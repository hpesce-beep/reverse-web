"use client";

import Link from "next/link";
import { BarChart3, Store, Gavel } from "lucide-react";
import { ChevronRight } from "lucide-react";

const RESULTADOS = [
  {
    icon: BarChart3,
    title: "Transformación y valorización estratégica de activos",
    description: "Evaluación técnica/comercial y estrategia de recuperación.",
  },
  {
    icon: Store,
    title: "Reverse Marketplace (B2B con IA)",
    description: "Matching óptimo, valorización predictiva y trazabilidad documental.",
  },
  {
    icon: Gavel,
    title: "Subastas y ventas (martillero)",
    description: "Procesos estructurados, transparentes y auditables.",
  },
];

export function SolucionIntegralSection() {
  return (
    <section className="py-14 lg:py-20 bg-reverse-soft-bg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-sm font-semibold text-reverse-muted uppercase tracking-[0.15em]">
          El resultado
        </p>
        <h2 className="mt-3 text-display font-bold text-reverse-black">
          ¿Una solución integral?
        </h2>

        <ul className="mt-14 lg:mt-16 space-y-6 lg:space-y-8">
          {RESULTADOS.map((item, i) => (
            <li
              key={item.title}
              className="flex gap-6 items-start animate-fade-in rounded-reverse-lg border border-reverse-border bg-white p-6 lg:p-10 hover:border-reverse-blue/20 hover:shadow-reverse-md transition-all"
              style={{ animationDelay: `${i * 0.05}s` }}
            >
              <span className="shrink-0 w-14 h-14 rounded-reverse bg-reverse-blue flex items-center justify-center text-reverse-lime">
                <item.icon className="w-7 h-7" strokeWidth={2} />
              </span>
              <div>
                <h3 className="font-semibold text-reverse-black text-lg lg:text-xl">
                  {item.title}
                </h3>
                <p className="mt-2 text-reverse-secondary text-base lg:text-lg leading-relaxed">
                  {item.description}
                </p>
              </div>
            </li>
          ))}
        </ul>

        <div className="mt-12">
          <Link
            href="/que-hacemos"
            className="inline-flex items-center gap-1 text-base font-medium text-reverse-blue hover:text-reverse-lime transition-colors group"
          >
            Conocer el proceso completo
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </Link>
        </div>
      </div>
    </section>
  );
}
