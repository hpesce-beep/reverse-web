"use client";

import Image from "next/image";
import { Cpu, GitBranch, Globe } from "lucide-react";
import { Button } from "@/components/ui/Button";

const DIFERENCIADORES = [
  {
    icon: Cpu,
    title: "Tecnología + IA",
    description: "Analizamos la data, segmentamos y definimos la mejor salida por ítem (precio, canal, timing).",
  },
  {
    icon: GitBranch,
    title: "Ejecución end-to-end",
    description: "Proceso completo desde caracterización hasta venta, con trazabilidad.",
  },
  {
    icon: Globe,
    title: "Alcance comercial",
    description: "Marketplace + subastas + red de compradores (Chile e internacional).",
  },
];

export function ValueProposition() {
  return (
    <section className="relative py-14 lg:py-20 pb-16 lg:pb-24 bg-reverse-blue overflow-hidden" style={{ backgroundColor: "#4495F0" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-sm font-semibold text-reverse-lime uppercase tracking-[0.2em]">
          Nuestra propuesta de valor
        </p>
        <h2 className="mt-3 text-display font-bold text-white">
          ¿Qué nos diferencia?
        </h2>

        <div className="mt-16 grid sm:grid-cols-3 gap-10 lg:gap-14">
          {DIFERENCIADORES.map((item) => (
            <div key={item.title} className="animate-fade-in">
              <div className="inline-flex w-14 h-14 rounded-reverse-lg bg-reverse-lime/20 border border-reverse-lime/30 items-center justify-center text-reverse-lime">
                <item.icon className="w-7 h-7" strokeWidth={2} />
              </div>
              <h3 className="mt-5 text-xl lg:text-2xl font-bold text-white">
                {item.title}
              </h3>
              <p className="mt-3 text-white/90 text-lg leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-16 flex flex-col items-center w-full">
          <p className="text-base lg:text-lg text-white/85 mb-8 text-center max-w-3xl">
            Liquidación tradicional 1–2% de recupero vs. Reverse con motor de decisión con IA y canales especializados: 25%+ de recupero.
          </p>
          <div className="w-full max-w-6xl rounded-reverse-lg overflow-hidden border-2 border-white/20 shadow-2xl bg-white/5">
            <Image
              src="/images/diferenciador-reverse.png"
              alt="Cómo nos diferenciamos: empresas tradicionales 1-2% recupero con liquidación uniforme vs Reverse 25%+ con motor de decisión IA y canales especializados (Marketplace, Venta directa, Asset-backed investors, Subasta)."
              width={1400}
              height={900}
              className="w-full h-auto"
              priority
              unoptimized
            />
          </div>
        </div>

        <div className="mt-14">
          <Button href="/contacto" variant="primary" className="bg-reverse-lime text-reverse-black hover:opacity-90">
            Agendar reunión
          </Button>
        </div>
      </div>
    </section>
  );
}
