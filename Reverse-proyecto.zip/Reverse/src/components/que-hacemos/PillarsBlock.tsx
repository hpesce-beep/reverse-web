"use client";

import { BarChart3, Store, Gavel, Truck, Network } from "lucide-react";
import { pillars } from "@/data/marketplaces";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  chart: BarChart3,
  store: Store,
  gavel: Gavel,
  truck: Truck,
  network: Network,
};

export function PillarsBlock() {
  return (
    <section className="py-16 lg:py-24 bg-gradient-to-b from-reverse-soft-bg to-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 lg:mb-14">
          <p className="text-base sm:text-lg font-semibold text-reverse-secondary uppercase tracking-[0.15em]">
            Nuestros pilares
          </p>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-[2.5rem] font-bold text-reverse-black tracking-tight">
            Los cinco pilares
          </h2>
          <p className="mt-4 text-reverse-secondary text-base lg:text-lg leading-relaxed">
            Abordamos el desafío de punta a punta: desde el diagnóstico hasta la captura de valor.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5 lg:gap-6">
          {pillars.map((pillar, i) => {
            const Icon = iconMap[pillar.icon] ?? BarChart3;
            const num = String(i + 1).padStart(2, "0");
            const isLime = i % 2 === 0;
            return (
              <div
                key={pillar.id}
                className="group relative rounded-2xl border border-reverse-border bg-white p-5 sm:p-6 shadow-sm transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-reverse-lime/40 flex flex-col items-center text-center"
              >
                <div
                  className={`absolute inset-x-0 top-0 h-1 rounded-t-2xl ${
                    isLime ? "bg-reverse-lime/50" : "bg-reverse-blue/50"
                  }`}
                  aria-hidden
                />
                <span
                  className={`absolute top-4 right-4 w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm tabular-nums text-reverse-black ${
                    isLime ? "bg-reverse-lime/15" : "bg-reverse-blue/10"
                  }`}
                >
                  {num}
                </span>
                <div className="flex flex-col h-full pt-2 w-full items-center">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl flex items-center justify-center bg-reverse-soft-bg text-reverse-black border border-reverse-border shrink-0">
                    <Icon className="w-8 h-8 sm:w-10 sm:h-10" />
                  </div>
                  <h3 className="mt-4 font-bold text-reverse-black text-base sm:text-lg leading-snug">
                    {pillar.title}
                  </h3>
                  <p className="mt-2 text-reverse-secondary text-sm sm:text-[0.9375rem] leading-relaxed flex-1 text-left">
                    {pillar.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
