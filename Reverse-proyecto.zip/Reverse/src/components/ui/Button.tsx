import Link from "next/link";

type ButtonVariant = "primary" | "secondary" | "outline";

interface ButtonBaseProps {
  children: React.ReactNode;
  className?: string;
  variant?: ButtonVariant;
  external?: boolean;
}

const variantStyles: Record<ButtonVariant, string> = {
  primary:
    "bg-reverse-lime text-reverse-black hover:opacity-90 focus:ring-reverse-lime",
  secondary:
    "bg-reverse-blue text-white hover:opacity-90 focus:ring-reverse-blue",
  outline:
    "border-2 border-reverse-blue text-reverse-blue bg-transparent hover:bg-reverse-blue hover:text-gray-200 focus:ring-reverse-blue",
};

const baseStyles =
  "inline-flex items-center justify-center rounded-reverse px-5 py-2.5 text-sm font-semibold transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50";

type ButtonProps = ButtonBaseProps & (
  | { href: string; type?: never }
  | { href?: never; type?: "button" | "submit" }
);

export function Button({
  children,
  className = "",
  variant = "primary",
  external,
  ...props
}: ButtonProps) {
  const styles = `${baseStyles} ${variantStyles[variant]} ${className}`;

  if ("href" in props && props.href) {
    const { href, type: _t, ...rest } = props;
    if (external) {
      return (
        <a href={href} target="_blank" rel="noopener noreferrer" className={styles} {...rest}>
          {children}
        </a>
      );
    }
    return <Link href={href} className={styles} {...rest}>{children}</Link>;
  }

  const { type, ...buttonRest } = props;
  return (
    <button type={type ?? "button"} className={styles} {...buttonRest}>
      {children}
    </button>
  );
}
