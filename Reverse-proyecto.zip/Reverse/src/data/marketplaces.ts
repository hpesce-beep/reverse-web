export type ItemType = "marketplace" | "auction";
export type ItemStatus = "active" | "upcoming";

export interface MarketplaceItem {
  id: string;
  title: string;
  description: string;
  type: ItemType;
  status: ItemStatus;
  industry?: string;
  country?: string;
  tags: string[];
  url: string;
  endDate?: string;
  imageUrl?: string;
}

/**
 * Marketplaces y subastas que se muestran en /marketplaces y en el preview del home.
 *
 * CÓMO AÑADIR UN NUEVO MARKETPLACE O SUBASTA:
 * 1. Añade un nuevo objeto dentro del array [ ... ] con un id único (ej. "m4" o "a4").
 * 2. type: "marketplace" para marketplace, "auction" para subasta.
 * 3. status: "active" (visible y destacado) o "upcoming" (próximamente).
 * 4. Rellena title, description, url y tags. Opcional: industry, country, endDate (útil en subastas), imageUrl.
 * 5. Guarda el archivo; la página /marketplaces y el home se actualizan solas.
 */
export const marketplacesData: MarketplaceItem[] = [
  {
    id: "m1",
    title: "Marketplace MRO Industrial",
    description: "Repuestos y equipos MRO para minería e industria. Liquidación con trazabilidad completa.",
    type: "marketplace",
    status: "active",
    industry: "Minería",
    country: "Chile",
    tags: ["MRO", "repuestos", "trazabilidad"],
    url: "https://example.com/mro",
  },
  {
    id: "a1",
    title: "Subasta Activos Energía",
    description: "Equipos y activos de energía renovable. Subasta transparente con documentación auditable.",
    type: "auction",
    status: "upcoming",
    industry: "Energía",
    country: "Chile",
    tags: ["energía", "subasta", "auditable"],
    url: "https://example.com/auction-energy",
    endDate: "2025-04-15",
  },
  {
    id: "m2",
    title: "Excedentes Manufactura",
    description: "Inventario excedente de manufactura. Valorización y venta B2B con recupero optimizado.",
    type: "marketplace",
    status: "active",
    industry: "Manufactura",
    country: "Chile",
    tags: ["excedentes", "B2B", "recupero"],
    url: "https://example.com/manufactura",
  },
  {
    id: "a2",
    title: "Subasta Activos Mineros",
    description: "Maquinaria y componentes mineros. Proceso end-to-end con IA para matching de compradores.",
    type: "auction",
    status: "active",
    industry: "Minería",
    country: "Chile",
    tags: ["minería", "IA", "liquidación"],
    url: "https://example.com/auction-mineria",
  },
  {
    id: "m3",
    title: "Marketplace Logística",
    description: "Activos de logística y almacenamiento. Menos inventario, más espacio y menor costo.",
    type: "marketplace",
    status: "active",
    industry: "Logística",
    country: "Chile",
    tags: ["logística", "almacenamiento", "espacio"],
    url: "https://example.com/logistica",
  },
  {
    id: "a3",
    title: "Subasta Equipos Tecnología",
    description: "Equipos IT y tecnología. Valorización predictiva y venta con trazabilidad digital.",
    type: "auction",
    status: "upcoming",
    industry: "Tecnología",
    country: "Chile",
    tags: ["tecnología", "trazabilidad", "valorización"],
    url: "https://example.com/auction-tech",
    endDate: "2025-05-01",
  },
];

export const pillars = [
  {
    id: "p1",
    title: "Valorización y segmentación",
    description: "Diagnóstico y clasificación de activos para maximizar recupero y liquidez. Análisis técnico y comercial.",
    icon: "chart",
  },
  {
    id: "p2",
    title: "Reverse Marketplace (B2B)",
    description: "Plataforma con IA: matching óptimo, valorización predictiva y trazabilidad documental.",
    icon: "store",
  },
  {
    id: "p3",
    title: "Subastas y ventas",
    description: "Procesos estructurados, transparentes y auditables. Martillero y canales dedicados.",
    icon: "gavel",
  },
  {
    id: "p4",
    title: "Logística integrada",
    description: "Bodega, custodia y acondicionamiento con trazabilidad digital mientras se comercializa.",
    icon: "truck",
  },
  {
    id: "p5",
    title: "Red global de compradores / activos especiales",
    description: "Conexión con inversionistas y compradores especializados (Chile e internacional).",
    icon: "network",
  },
] as const;

export const processSteps = [
  { step: "01", title: "Diagnóstico", description: "Caracterización técnica y económica del inventario. Valorización preliminar, mapeo de mercado y objetivos (caja, disponibilidad, espacio)." },
  { step: "02", title: "Valorización", description: "Normalización y clusterización por valor y rotación. Escenarios de salida y estrategia de negociación por lote." },
  { step: "03", title: "Preparación", description: "Segmentación y lotificación. Evaluación legal y tributaria. Definición de estrategia final (Marketplace, Subasta, Venta directa)." },
  { step: "04", title: "Ejecución comercial", description: "Difusión, ofertas, contraofertas y showrooms. Confirmación de transacción, documentación y trazabilidad." },
  { step: "05", title: "Captura de valor y reporting", description: "Reporte de resultados (recupero, tiempos, eficiencia). Insights para futuras optimizaciones." },
] as const;

export const featureBadges = [
  { id: "ai", title: "IA y analítica", description: "Matching predictivo y valorización con datos." },
  { id: "trace", title: "Trazabilidad", description: "Proceso end-to-end auditable y transparente." },
  { id: "sustainability", title: "Sostenibilidad", description: "Economía circular y mejor uso de activos." },
] as const;

export const faqItems = [
  { q: "¿Qué tipos de activos pueden valorizarse?", a: "Inventario MRO, repuestos, equipos, excedentes industriales y activos en dificultad. Trabajamos con minería, energía, manufactura y logística." },
  { q: "¿Cómo se garantiza la trazabilidad?", a: "Documentación digital, registros auditables y plataforma integrada en cada etapa del proceso, desde diagnóstico hasta liquidación." },
  { q: "¿Cuánto tarda el proceso?", a: "Depende del volumen y tipo de activos. El diagnóstico inicial puede tomar días; la ejecución comercial, semanas según estrategia (marketplace o subasta)." },
  { q: "¿Qué necesito para empezar?", a: "Inventario o listado de activos, información básica de condición y ubicación. Nosotros realizamos el diagnóstico y proponemos la estrategia." },
  { q: "¿Cómo se compara el recupero vs liquidación tradicional?", a: "Las liquidaciones con martilleros tradicionales suelen alcanzar 1–2% del valor libro. Nuestra metodología con tecnología y canales dedicados históricamente supera ese rango (ej. +22% a +32% en casos de éxito)." },
  { q: "¿Ofrecen subastas con martillero?", a: "Sí. Procesos estructurados, transparentes y auditables con martillero público, además de marketplace B2B y venta directa según el activo." },
  { q: "¿Trabajan solo en Chile?", a: "Tenemos alcance comercial en Chile e internacional a través de red de compradores y plataformas. La operación base es Chile." },
  { q: "¿Qué entregables recibo?", a: "Reportes de resultados (recupero, tiempos, eficiencia), documentación completa y trazabilidad. Insights para futuras optimizaciones de inventario." },
] as const;

/** Logos de clientes actuales (ruta en public/clients/) */
/** Logos en public/clients/. Si el PNG trae fondo negro, marcar darkBg: true para usar contenedor oscuro. */
export const clientLogos = [
  { name: "Siderúrgica Huachipato", src: "/clients/huachipato.png" },
  { name: "Celsia", src: "/clients/celsia.png" },
  { name: "AquaChile", src: "/clients/aquachile.png" },
  { name: "Starbucks", src: "/clients/starbucks.png" },
] as const;

/** Equipo Reverse (para Quiénes somos). Fotos en public/team/. */
export const teamMembers = [
  {
    id: "1",
    name: "Roberto Uauy",
    role: "Socio Xinergy, Especialista Abastecimiento",
    bio: "Especialista en reducción de costos y optimización de procesos vía negociación estratégica y adopción tecnológica. +15 años liderando proyectos en múltiples industrias.",
    email: "roberto.uauy@xinergy.cl",
    initials: "RU",
    photo: "/team/roberto.png",
  },
  {
    id: "2",
    name: "Sebastián Flores",
    role: "Socio Dux, Especialista Supply Chain",
    bio: "+20 años liderando transformaciones organizacionales y modelos operacionales en Supply Chain. Experto en eficiencia, negociación de grandes contratos, flota y distribución (ex LATAM Airlines).",
    email: "sflores@duxpartners.com",
    initials: "SF",
    photo: "/team/sebastian.png",
  },
  {
    id: "3",
    name: "Gonzalo Aguirrebeña",
    role: "CEO Reverse, Abogado y Martillero público",
    bio: "+17 años en la industria financiera liderando funciones ejecutivas de Compliance y Legal, habilitando crecimiento y desarrollo de negocios (Grupo Santander).",
    email: "gonzalo.aguirrebena@xinergy.cl",
    initials: "GA",
    photo: "/team/gonzalo.png",
  },
  {
    id: "4",
    name: "Diego Jorreto",
    role: "Gerente Comercial",
    bio: "7 años liderando transformaciones de compras y abastecimiento estratégico: equipos, procesos y gobierno. Experiencia en procurement regional (Falabella) y liderazgo de compras en Copec/Energía Solar.",
    email: "diego.jorreto@xinergy.cl",
    initials: "DJ",
    photo: "/team/diego.png",
  },
  {
    id: "5",
    name: "Catalina Bravo",
    role: "Consultor",
    bio: "+3 años en abastecimiento estratégico, finanzas y control operacional en industrias altamente competitivas. Experiencia multi-categoría, generación de eficiencias y análisis de inventario.",
    email: "catalina.bravo@xinergy.cl",
    initials: "CB",
    photo: "/team/cata.png",
  },
] as const;

/** Ecosistema: entidades con logos (orden: Opticks, Dux, Xinergy, Reverse) */
export const ecosystemEntities = [
  { name: "Reverse", tagline: "Valorización y ejecución comercial", logo: "/logos/reverse.png" },
  { name: "Xinergy", tagline: "Supply chain technology", logo: "/logos/xinergy.png" },
  { name: "Duxpartners", tagline: "Supply chain empowerment", logo: "/logos/dux.png" },
  { name: "OpticksAI", tagline: "Supply chain analytics", logo: "/logos/opticks.png" },
] as const;

/** Placeholders para testimonios (2 cortos) */
export const testimonials = [
  {
    quote: "Reverse nos permitió recuperar liquidez de inventario que llevaba años inmovilizado, con un proceso claro y trazable.",
    role: "Supply Chain",
    industry: "Energía",
  },
  {
    quote: "La valorización y el canal de subasta nos dieron un recupero muy por encima de lo que habíamos visto con liquidaciones tradicionales.",
    role: "Operaciones",
    industry: "Minería",
  },
] as const;
