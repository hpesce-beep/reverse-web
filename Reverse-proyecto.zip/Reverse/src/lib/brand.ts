/**
 * Reverse brand tokens — single source for colors and typography.
 * Change here to update the whole site.
 */

export const brand = {
  colors: {
    lime: "#73C544",
    limeMuted: "rgba(115, 197, 68, 0.15)",
    blue: "#4495F0",
    blueLight: "rgba(68, 149, 240, 0.15)",
    black: "#0A0A0A",
    secondary: "#111827",
    muted: "#6B7280",
    border: "#E5E7EB",
    softBg: "#F6F7F9",
    white: "#FFFFFF",
  },
  typography: {
    h1: "clamp(2.5rem, 5vw, 4rem)",   // 40–64px
    h2: "clamp(2rem, 4vw, 2.75rem)",  // 32–44px
    body: "1rem",                      // 16px
    bodyLg: "1.125rem",                // 18px
    caption: "0.8125rem",              // 13px
    captionSm: "0.75rem",              // 12px
  },
  radius: {
    card: "1rem",   // 16px
    button: "1rem",
    input: "0.75rem",
  },
  spacing: {
    section: "5rem",
    sectionLg: "6rem",
  },
} as const;
